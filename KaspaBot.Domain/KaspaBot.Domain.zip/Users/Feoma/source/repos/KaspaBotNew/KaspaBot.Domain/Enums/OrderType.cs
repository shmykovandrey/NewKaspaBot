﻿namespace KaspaBot.Domain.Enums;

public enum OrderType
{
    Market,
    Limit
}
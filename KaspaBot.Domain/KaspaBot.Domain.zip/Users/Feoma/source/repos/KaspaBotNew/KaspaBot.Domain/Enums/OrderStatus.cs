﻿namespace KaspaBot.Domain.Enums;

public enum OrderStatus
{
    New,
    Filled,
    Canceled,
    PartiallyFilled,
    PartiallyCanceled
}
﻿using CryptoExchange.Net.Authentication;
using CryptoExchange.Net.Objects;
using FluentResults;
using KaspaBot.Domain.Entities;
using KaspaBot.Domain.Enums;
using KaspaBot.Domain.Interfaces;
using KaspaBot.Infrastructure.Options;
using Mexc.Net.Clients;
using Mexc.Net.Enums;
using Mexc.Net.Objects.Models.Spot;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace KaspaBot.Infrastructure.Services;

public class MexcService : IMexcService
{
    private readonly Mexc.Net.Clients.MexcRestClient _restClient;
    private readonly Mexc.Net.Clients.MexcSocketClient _socketClient;
    private readonly ILogger<MexcService> _logger;

    public MexcService(IOptions<MexcOptions> options, ILogger<MexcService> logger)
    {
        _logger = logger;
        _restClient = new Mexc.Net.Clients.MexcRestClient(opts =>
        {
            opts.ApiCredentials = new ApiCredentials(
                options.Value.ApiKey,
                options.Value.ApiSecret);
        });

        _socketClient = new Mexc.Net.Clients.MexcSocketClient(opts =>
        {
            opts.ApiCredentials = new ApiCredentials(
                options.Value.ApiKey,
                options.Value.ApiSecret);
        });
    }

    public async Task<Result<Order>> PlaceOrderAsync(
        string symbol,
        Domain.Enums.OrderSide side,
        Domain.Enums.OrderType type,
        decimal quantity,
        decimal? price = null,
        CancellationToken ct = default)
    {
        try
        {
            WebCallResult<MexcOrder> result;

            Mexc.Net.Enums.OrderSide mexcSide = side == Domain.Enums.OrderSide.Buy
                ? Mexc.Net.Enums.OrderSide.Buy
                : Mexc.Net.Enums.OrderSide.Sell;

            Mexc.Net.Enums.OrderType mexcType = type == Domain.Enums.OrderType.Market
                ? Mexc.Net.Enums.OrderType.Market
                : Mexc.Net.Enums.OrderType.Limit;

            if (type == Domain.Enums.OrderType.Market)
            {
                result = side == Domain.Enums.OrderSide.Buy
                    ? await _restClient.SpotApi.Trading.PlaceOrderAsync(
                        symbol,
                        mexcSide,
                        mexcType,
                        quoteQuantity: quantity,
                        ct: ct)
                    : await _restClient.SpotApi.Trading.PlaceOrderAsync(
                        symbol,
                        mexcSide,
                        mexcType,
                        quantity: quantity,
                        ct: ct);
            }
            else
            {
                result = await _restClient.SpotApi.Trading.PlaceOrderAsync(
                    symbol,
                    mexcSide,
                    mexcType,
                    quantity: quantity,
                    price: price,
                    timeInForce: TimeInForce.GoodTillCanceled,
                    ct: ct);
            }

            if (!result.Success)
            {
                _logger.LogError("Failed to place order: {Error}", result.Error);
                return Result.Fail(result.Error.Message);
            }

            return Result.Ok(MapToDomainOrder(result.Data));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error placing order");
            return Result.Fail(ex.Message);
        }
    }

    private Order MapToDomainOrder(MexcOrder order)
    {
        return new Order
        {
            Id = order.OrderId,
            Symbol = order.Symbol,
            Side = order.Side == Mexc.Net.Enums.OrderSide.Buy ? Domain.Enums.OrderSide.Buy : Domain.Enums.OrderSide.Sell,
            Type = order.OrderType == Mexc.Net.Enums.OrderType.Market ? Domain.Enums.OrderType.Market : Domain.Enums.OrderType.Limit,
            Quantity = order.Quantity,
            Price = order.Price,
            Status = (Domain.Enums.OrderStatus)order.Status,
            CreatedAt = order.CreateTime,
            QuantityFilled = order.QuantityFilled,
            QuoteQuantityFilled = order.QuoteQuantityFilled
        };
    }
}
﻿namespace KaspaBot.Infrastructure.Options;

public class MexcOptions
{
    public const string SectionName = "Mexc";

    public string ApiKey { get; set; }
    public string ApiSecret { get; set; }
}
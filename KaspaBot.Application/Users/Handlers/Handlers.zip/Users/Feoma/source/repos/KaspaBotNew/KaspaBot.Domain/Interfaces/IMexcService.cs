﻿using FluentResults;
using KaspaBot.Domain.Entities;
using KaspaBot.Domain.Enums;

namespace KaspaBot.Domain.Interfaces;

public interface IMexcService
{
    Task<Result<Order>> PlaceOrderAsync(
        string symbol,
        OrderSide side,
        OrderType type,
        decimal quantity,
        decimal? price = null,
        CancellationToken ct = default);
}
﻿using KaspaBot.Domain.Interfaces;
using Mexc.Net.Clients;
using Microsoft.Extensions.Logging;

namespace KaspaBot.Infrastructure.Services;

public class PriceStreamService : IPriceStreamService, IDisposable
{
    private readonly Mexc.Net.Clients.MexcSocketClient _socketClient;
    private readonly ILogger<PriceStreamService> _logger;
    private IDisposable _subscription;

    public PriceStreamService(ILogger<PriceStreamService> logger)
    {
        _logger = logger;
        _socketClient = new Mexc.Net.Clients.MexcSocketClient();
    }

    public async Task StartStreamAsync(string symbol, Action<decimal> onPriceUpdate)
    {
        _subscription = await _socketClient.SpotApi.SubscribeToMiniTickerUpdatesAsync(
            symbol,
            update => onPriceUpdate(update.Data.LastPrice));
    }

    public void Dispose()
    {
        _subscription?.Dispose();
        _socketClient?.Dispose();
    }
}
﻿namespace KaspaBot.Domain.Enums;

public enum OrderSide
{
    Buy,
    Sell
}